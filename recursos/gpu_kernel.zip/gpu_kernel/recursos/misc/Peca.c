#include <stdio.h>

typedef struct {
    int x, y;
    int formato[4][4];
} Peca;

Peca criar_peca(int tipo) {
    Peca peca;

    //acho que seria legal setar os formatos de peça de alguma forma e trazer para aqui de forma sorteada("radomicamnete")
    
    return peca;
}
